﻿using System;

namespace HgCo.WindowsLive.SkyDrive
{
    /// <summary>
    /// Provides webfolder content specific data.
    /// </summary>
    public class WebFolderInfo : WebFolderItemInfo
    {
        #region Properties
        
        /// <summary>
        /// Gets or sets ContentType.
        /// </summary>
        /// <value>The ContentType.</value>
        public WebFolderContentType ContentType { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="WebFolderInfo"/> class.
        /// </summary>
        public WebFolderInfo()
        {
            ItemType = WebFolderItemType.Folder;
        }

        #endregion
    }
}
