﻿using System;

namespace HgCo.WindowsLive.SkyDrive
{
    /// <summary>
    /// 
    /// </summary>
    public enum WebFolderContentType
    {
        /// <summary>
        /// 
        /// </summary>
        None,
        /// <summary>
        /// 
        /// </summary>
        Documents,
        /// <summary>
        /// 
        /// </summary>
        Favorites,
        /// <summary>
        /// 
        /// </summary>
        Photos
    }
}