﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HgCo.WindowsLive.SkyDrive.Support.Net.WebDav
{
    /// <summary>
    /// 
    /// </summary>
    public static class WebDavMethods
    {
        /// <summary>
        /// 
        /// </summary>
        public const string PROPFIND = "PROPFIND";

        /// <summary>
        /// 
        /// </summary>
        public const string MKCOL = "MKCOL";

        /// <summary>
        /// 
        /// </summary>
        public const string PUT = "PUT";

        /// <summary>
        /// 
        /// </summary>
        public const string DELETE = "DELETE";

        /// <summary>
        /// 
        /// </summary>
        public const string MOVE = "MOVE";

        /// <summary>
        /// 
        /// </summary>
        public const string COPY = "COPY";
    }
}
