﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HgCo.WindowsLive.SkyDrive.Support.Net.Soap
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public abstract class SoapWebResponse
    {
    }
}
