﻿
namespace DropNet.Tests
{
    public static class TestVariables
    {
        //Insert yo stuff here to run the tests
        public static string ApiKey = "ApiKey";
        public static string ApiSecret = "ApiSecret";
        public static string Email = "Email";
        public static string Password = "Password";
    }
}
