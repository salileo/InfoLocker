﻿
namespace DropNet.CLI
{
	public class ApplicationDefaults
	{
		// DropNet.CLI app registration
		public const string AppKey = "qxh112htz4r9i60";
		public const string AppSecret = "33osupoysq73j39";
	}
}
