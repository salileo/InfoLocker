//
//  main.m
//  DBSmokeTester
//
//  Created by Zed Shaw on 4/23/10.
//  Copyright Dropbox 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
