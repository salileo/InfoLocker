#import <Cocoa/Cocoa.h>


@interface TestController : NSObject {
}

- (IBAction)runtests:(id)sender;	
@end

