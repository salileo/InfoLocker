/* Set these to whatever you use to log in and such. */

// the USERNAME and PASSWORD are only needed for testing purposes, normally these wouldn't go in your application
NSString *USERNAME = @"your@login.com";
NSString *PASSWORD = @"yourpassword";
NSString *CONSUMERKEY = @"yourconsumerkey";
NSString *CONSUMERSECRET = @"yoursecret";

