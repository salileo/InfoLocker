﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppLimit.CloudComputing.SharpBox.DropBox.Helper
{
    internal class WebBrowserDialogParameterHelper
    {
        public Type DlgType;

        public Object Result;

        public WebBrowserDialogParameter Parameters; 
    }
}
