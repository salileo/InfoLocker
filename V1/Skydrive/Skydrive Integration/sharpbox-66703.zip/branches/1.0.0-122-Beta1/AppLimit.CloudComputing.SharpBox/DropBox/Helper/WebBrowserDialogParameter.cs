﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppLimit.CloudComputing.SharpBox.DropBox.Helper
{
    internal class WebBrowserDialogParameter
    {
        public String Url;

        public Boolean ShowHidden;
    }
}
