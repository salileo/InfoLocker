﻿using System;

namespace HgCo.WindowsLive.SkyDrive
{
    /// <summary>
    /// 
    /// </summary>
    public enum WebFolderItemShareType
    {
        /// <summary>
        /// 
        /// </summary>
        None,
        /// <summary>
        /// 
        /// </summary>
        Public,
        /// <summary>
        /// 
        /// </summary>
        MyNetwork,
        /// <summary>
        /// 
        /// </summary>
        PeopleSelected,
        /// <summary>
        /// 
        /// </summary>
        Private
    }
}
