﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace HgCo.WindowsLive.SkyDrive
{
    /// <summary>
    /// Provides webfolderitem content specific data. This is an <c>abstract</c> class.
    /// </summary>
    public abstract class WebFolderItemInfo
    {
        #region Fields
        /// <summary>
        /// The delimiter character used in path URL.
        /// </summary>
        public const char PathUrlSegmentDelimiter = '/';

        /// <summary>
        /// 
        /// </summary>
        private readonly Regex RegexSize = new Regex("^(?i:\\s*(?<Quantity>\\d+(\\.\\d+)?)\\s+(?<Unit>(byte|bytes|kb|mb)))$");

        /// <summary>
        /// 
        /// </summary>
        private string size;
        
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the ItemType.
        /// </summary>
        /// <value>The ItemType.</value>
        public WebFolderItemType ItemType { get; protected set; }

        /// <summary>
        /// Gets or sets the name of the item's creator.
        /// </summary>
        /// <value>The name of the item's creator.</value>
        public string CreatorName { get; set; }

        /// <summary>
        /// Gets or sets the URI to the creator's profile.
        /// </summary>
        /// <value>The URI to the creator's profile.</value>
        public Uri CreatorUri { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the ShareType.
        /// </summary>
        /// <value>The ShareType.</value>
        public WebFolderItemShareType ShareType { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>The size.</value>
        public string Size 
        {
            get { return size; }
            set 
            {
                size = value;
                if (!String.IsNullOrEmpty(size) && RegexSize.IsMatch(size))
                {
                    Match matchSize = RegexSize.Match(size);
                    decimal quantity = Decimal.Parse(matchSize.Groups["Quantity"].Value, CultureInfo.InvariantCulture);
                    string unit = matchSize.Groups["Unit"].Value.ToLower();
                    switch (unit)
                    {
                        case "kb":
                            SizeMean = (int)Math.Round(quantity * 1024);
                            SizeMin = (int)Math.Round((quantity - 0.049M) * 1024);
                            SizeMax = (int)Math.Round((quantity + 0.005M) * 1024);
                            break;
                        case "mb":
                            SizeMean = (int)Math.Round(quantity * 1024 * 1024);
                            SizeMin = (int)Math.Round((quantity - 0.049M) * 1024 * 1024);
                            SizeMax = (int)Math.Round((quantity + 0.005M) * 1024 * 1024);
                            break;
                        default:
                            SizeMean = SizeMin = SizeMax = (int)Math.Round(quantity);
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the mean size in bytes.
        /// </summary>
        /// <value>The mean size in bytes.</value>
        public int? SizeMean { get; private set; }
        
        /// <summary>
        /// Gets or sets the min size in bytes.
        /// </summary>
        /// <value>The min size in bytes.</value>
        public int? SizeMin { get; private set; }

        /// <summary>
        /// Gets or sets the max size in bytes.
        /// </summary>
        /// <value>The max size in bytes.</value>
        public int? SizeMax { get; private set; }

        /// <summary>
        /// Gets or sets the date when item was added.
        /// </summary>
        /// <value>The date when item was added.</value>
        public DateTime? DateAdded { get; set; }

        /// <summary>
        /// Gets or sets the date when item was modified.
        /// </summary>
        /// <value>The date when item was modified.</value>
        public DateTime? DateModified { get; set; }

        /// <summary>
        /// Gets or sets the path URL.
        /// </summary>
        /// <value>The path URL.</value>
        public string PathUrl { get; set; }

        /// <summary>
        /// Gets or sets the URI to view the item.
        /// </summary>
        /// <value>The view URI.</value>
        public Uri ViewUri { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
        /// </returns>
        public override string ToString()
        {
            if (String.IsNullOrEmpty(Name))
                return ShareType != WebFolderItemShareType.None ?
                    String.Format(CultureInfo.InvariantCulture, "{0} ({1})", PathUrl, ShareType) : PathUrl;
            else
                return ShareType != WebFolderItemShareType.None ?
                    String.Format(CultureInfo.InvariantCulture, "{0} ({1})", Name, ShareType) : Name;
        }

        /// <summary>
        /// Gets an array containing the path segments that make up the specified path URL.
        /// </summary>
        /// <param name="pathUrl">The path URL.</param>
        /// <returns>The segments of the path URL.</returns>
        public static string[] GetPathUrlSegments(string pathUrl)
        {
            string[] pathUrlSegments = null;
            if (!String.IsNullOrEmpty(pathUrl))
                pathUrlSegments = pathUrl.StartsWith(PathUrlSegmentDelimiter.ToString()) ? 
                    pathUrl.Substring(1).Split(PathUrlSegmentDelimiter) :
                    pathUrl.Split(PathUrlSegmentDelimiter);
            return pathUrlSegments;
        }
        #endregion
    }
}
