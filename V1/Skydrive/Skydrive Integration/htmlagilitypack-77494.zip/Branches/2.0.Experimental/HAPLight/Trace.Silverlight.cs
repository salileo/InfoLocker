﻿namespace HtmlAgilityPack
{
    internal partial class Trace
    {
        partial void WriteLineIntern(string message,string category)
        {
        } 
    }
}
