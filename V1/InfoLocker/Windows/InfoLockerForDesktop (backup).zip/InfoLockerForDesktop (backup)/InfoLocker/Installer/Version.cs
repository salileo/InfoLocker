using System;
namespace ProductVersion { class VersionInfo { static public string Version { get { return "1.0.572"; } } } }
