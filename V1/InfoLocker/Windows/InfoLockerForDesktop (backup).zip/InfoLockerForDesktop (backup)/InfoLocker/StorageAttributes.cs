﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace InfoLocker
{
    public class StorageAttributes : IStorageAttributes
    {
        private FileAttributes FileAttr { get; set; }
        public DateTime CreationTime { get; private set; }
        public DateTime LastWriteTime { get; private set; }
        public long FileSize { get; private set; }

        public StorageAttributes(string filename)
        {
            FileInfo info = new FileInfo(filename);
            FileAttr = info.Attributes;
            CreationTime = info.CreationTime;
            LastWriteTime = info.LastWriteTime;
            FileSize = info.Length;
        }

        public bool IsEqual(IStorageAttributes info)
        {
            return ((FileAttr == (info as StorageAttributes).FileAttr) &&
                    (CreationTime == info.CreationTime) &&
                    (LastWriteTime == info.LastWriteTime) &&
                    (FileSize == info.FileSize));
        }
    }
}
