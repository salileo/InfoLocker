﻿using System;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.ComponentModel;
using System.Timers;

namespace InfoLocker
{
    public class Node_Common : INotifyPropertyChanged
    {
        #region SupportedTypes
        public enum Type { Folder, Note, Unknown };
        #endregion

        #region PublicProperties
        public Type NodeType { get { return m_nodeType; } }
        public string ID { get; protected set; }

        public long Version { get; protected set; }
        public long LastSyncedVersion { get; protected set; }

        public BitmapImage Icon { get { return m_icon; } }

        public string Name
        {
            get { return m_name; }
            set
            {
                if (!string.IsNullOrEmpty(value) && (m_name != value))
                {
                    m_name = value;
                    NotifyPropertyChanged("Name");
                    IsDirty = true;
                }
            }
        }
        
        public Node_Folder Parent
        {
            get { return m_parent; }
            set
            {
                if (m_parent != value)
                {
                    m_parent = value;
                    NotifyPropertyChanged("Parent");

                    if (m_parent != null)
                        Store = m_parent.Store;

                    IsDirty = true;

                }
            }
        }

        public StorageFile Store
        {
            get { return m_store; }
            set
            {
                if (m_store != value)
                {
                    m_store = value;
                    NotifyPropertyChanged("Store");
                    IsDirty = true;

                    if (NodeType == Type.Folder)
                    {
                        foreach (Node_Folder folder in (this as Node_Folder).SubFolders)
                            folder.Store = m_store;
                        foreach (Node_Note note in (this as Node_Folder).SubNotes)
                            note.Store = m_store;
                    }
                }
            }
        }

        public int IconID
        {
            get { return m_iconID; }
            set
            {
                if (m_iconID != value)
                {
                    m_iconID = value;
                    NotifyPropertyChanged("IconID");
                    IsDirty = true;
                }
            }
        }

        public DateTime? NotificationTime
        {
            get { return m_notifyTime; }
            set
            {
                if (m_notifyTime != value)
                {
                    m_notifyTime = value;
                    NotifyPropertyChanged("NotificationTime");
                    IsDirty = true;
                }
            }
        }

        public string NotificationText
        {
            get { return m_notifyText; }
            set
            {
                string input = (value == null) ? string.Empty : value;
                if (m_notifyText != input)
                {
                    m_notifyText = input;
                    NotifyPropertyChanged("NotificationText");
                    IsDirty = true;
                }
            }
        }

        public bool IsDirty
        {
            get { return m_dirty; }
            set
            {
                if (m_dirty != value)
                {
                    m_dirty = value;
                    NotifyPropertyChanged("IsDirty");

                    //if this node is dirty, then its parent is also dirty
                    //if this node is not dirty then its children are also not dirty

                    if (m_dirty)
                    {
                        if (Parent != null)
                            Parent.IsDirty = true;
                    }
                    else
                    {
                        if (NodeType == Type.Folder)
                        {
                            foreach (Node_Folder folder in (this as Node_Folder).SubFolders)
                                folder.IsDirty = false;
                            foreach (Node_Note note in (this as Node_Folder).SubNotes)
                                note.IsDirty = false;
                        }
                    }
                }
            }
        }
        #endregion

        #region PrivateMembers
        private Type m_nodeType;
        private BitmapImage m_icon;
        private string m_name;
        private Node_Folder m_parent;
        private StorageFile m_store;
        private bool m_dirty;
        #endregion

        public Node_Common(Type type)
        {
            m_nodeType = type;

            if (type == Type.Folder)
                m_icon = Utils.GetFolderIcon();
            else if (type == Type.Note)
                m_icon = Utils.GetNoteIcon();

            m_name = string.Empty;
            m_parent = null;
            m_dirty = false;
        }

        public virtual Node_Common Find(string searchstring)
        {
            return null;
        }

        #region Statics
        public static int DiffName(Node_Common a, Node_Common b)
        {
            return a.Name.CompareTo(b.Name);
        }
        #endregion

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string prop)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
        #endregion
    }
}
