﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Diagnostics;

namespace InfoLockerData
{
    public class Node_Folder : Node_Common
    {
        #region PublicProperties
        public List<Node_Common> SubNodes
        {
            get
            {
                List<Node_Common> nodes = new List<Node_Common>();
                nodes.AddRange(SubFolders);
                nodes.AddRange(SubNotes);
                return nodes;
            }
        }

        public List<Node_Folder> SubFolders { get; private set; }
        public List<Node_Note> SubNotes { get; private set; }
        #endregion

        public Node_Folder() : base(Node_Common.Type.Folder)
        {
            SubFolders = new List<Node_Folder>();
            SubNotes = new List<Node_Note>();
            this.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(OnSelfPropertyChanged);
        }

        void OnSelfPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ((e.PropertyName == "SubFolders") ||
                (e.PropertyName == "SubNotes"))
            {
                NotifyPropertyChanged("SubNodes");
            }
        }

        #region PublicMethods
        public void AddNode(Node_Common node)
        {
            if (node == null)
                throw (new Exception("No node specified for addition"));

            if (SubFolders.Contains(node) || SubNotes.Contains(node))
            {
                //node already a child of this folder
                node.Parent = this;
                return;
            }

            if (node.Parent == this)
            {
                //node is not in this folder's list but for some reason the parent property points to this node.
                //reset the parent property
                node.Parent = null;
            }

            if (node.Parent != null)
                node.Parent.RemoveNode(node);

            if (node.NodeType == Type.Folder)
            {
                SubFolders.Add(node as Node_Folder);
                SubFolders.Sort(Node_Common.DiffName);
                node.Parent = this;
                NotifyPropertyChanged("SubFolders");
            }
            else if (node.NodeType == Type.Note)
            {
                SubNotes.Add(node as Node_Note);
                SubNotes.Sort(Node_Common.DiffName);
                node.Parent = this;
                NotifyPropertyChanged("SubNotes");
            }

            IsDirty = true;
        }

        public void RemoveNode(Node_Common node)
        {
            if (node == null)
                throw (new Exception("No node specified for removal"));

            if (node.NodeType == Type.Folder)
            {
                if (!SubFolders.Remove(node as Node_Folder))
                    throw (new Exception("Could not remove node from folder"));

                node.Parent = null;
                NotifyPropertyChanged("SubFolders");
            }
            else if (node.NodeType == Type.Note)
            {
                if (!SubNotes.Remove(node as Node_Note))
                    throw (new Exception("Could not remove node from folder"));

                node.Parent = null;
                NotifyPropertyChanged("SubNotes");
            }

            IsDirty = true;
        }
        #endregion

        #region Serializer
        public override void Serialize(XmlWriter writer)
        {
            writer.WriteStartElement("Folder");
            writer.WriteAttributestring("Version", Version);
            writer.WriteAttributestring("Name", Name);
            writer.WriteAttributestring("IconID", IconID.ToString());
            writer.WriteAttributestring("NotificationText", NotificationText);

            if (NotificationTime != null)
                writer.WriteAttributestring("NotificationTime", NotificationTime.Value.ToString());

            foreach (Node_Folder folder in SubFolders)
                folder.Serialize(writer);

            foreach (Node_Note note in SubNotes)
                note.Serialize(writer);

            writer.WriteEndElement();
        }

        public override void DeSerialize(XmlReader reader)
        {
            m_deserializing = true;

            XmlReader subtree = reader.ReadSubtree();
            if (!subtree.Read())
                throw (new Exception("Error reading subtree"));

            Version = subtree.GetAttribute("Version");

            string name = subtree.GetAttribute("Name");
            if (name == null)
                throw (new Exception("Error reading name of folder"));
            else
                Name = name;

            string iconID = subtree.GetAttribute("IconID");
            if (iconID != null)
            {
                try
                {
                    IconID = int.Parse(iconID);
                }
                catch (Exception)
                {
                    //ignore error
                }
            }

            NotificationText = subtree.GetAttribute("NotificationText");

            string notificationTime = subtree.GetAttribute("NotificationTime");
            if (notificationTime != null)
            {
                try
                {
                    NotificationTime = DateTime.Parse(notificationTime);
                }
                catch (Exception)
                {
                    //ignore error
                }
            }

            while (subtree.Read())
            {
                if (subtree.NodeType == XmlNodeType.Element)
                {
                    if (subtree.Name == "Folder")
                    {
                        Node_Folder newfolder = new Node_Folder();
                        newfolder.DeSerialize(subtree);
                        AddNode(newfolder);
                    }
                    else if (subtree.Name == "Note")
                    {
                        Node_Note newnote = new Node_Note();
                        newnote.DeSerialize(subtree);
                        AddNode(newnote);
                    }
                    else
                    {
                        throw (new Exception("Unknown child '" + reader.Name + "' encountered"));
                    }
                }
            }

            subtree.Close();

            m_deserializing = false;
        }
        #endregion

        #region Operators
        public override bool IsEqual(Node_Common other)
        {
            if (other.NodeType == Type.Folder)
            {
                Node_Folder folder = other as Node_Folder;

                if ((folder != null) &&
                    this.Name.Equals(folder.Name) &&
                    this.SubFolders.Count == folder.SubFolders.Count &&
                    this.SubNotes.Count == folder.SubNotes.Count)
                {
                    int index = 0;
                    while (index < this.SubFolders.Count)
                    {
                        if (!this.SubFolders[index].IsEqual(folder.SubFolders[index]))
                            return false;

                        index++;
                    }

                    index = 0;
                    while (index < this.SubNotes.Count)
                    {
                        if (!this.SubNotes[index].IsEqual(folder.SubNotes[index]))
                            return false;

                        index++;
                    }

                    return true;
                }
            }

            return false;
        }

        public override bool Contains(string searchstring)
        {
            return this.Name.ToLower().Contains(searchstring);
        }
        #endregion
    }
}
