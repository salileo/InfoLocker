﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Diagnostics;

namespace InfoLockerData
{
    public class Node_Note : Node_Common
    {
        #region PublicProperties
        public string Content
        {
            get { return m_content; }
            set
            {
                string input = (value == null) ? string.Empty : value;
                if (m_content != input)
                {
                    m_content = input;
                    NotifyPropertyChanged("Content");
                    IsDirty = true;
                }
            }
        }
        #endregion

        #region PrivateMembers
        private string m_content;
        #endregion

        public Node_Note(bool assignId) : base(Node_Common.Type.Note, assignId)
        {
            m_content = string.Empty;
        }

        #region Serializer
        public override void Serialize(XmlWriter writer)
        {
            writer.WriteStartElement("Note");
            writer.WriteAttributestring("ID", ID);
            writer.WriteAttributestring("Version", Version.ToString());
            writer.WriteAttributestring("LastSyncedVersion", LastSyncedVersion.ToString());
            writer.WriteAttributestring("Active", Active.ToString());
            writer.WriteAttributestring("Name", Name);
            writer.WriteAttributestring("IconID", IconID.ToString());
            writer.WriteAttributestring("Content", Content);
            writer.WriteAttributestring("NotificationText", NotificationText);
            
            if (NotificationTime != null)
                writer.WriteAttributestring("NotificationTime", NotificationTime.Value.ToString());

            writer.WriteEndElement();
        }

        public override void DeSerialize(XmlReader reader)
        {
            m_deserializing = true;
            bool markDirty = false;

            XmlReader subtree = reader.ReadSubtree();
            if (!subtree.Read())
                throw (new Exception("Error reading subtree"));

            ID = subtree.GetAttribute("ID");
            if (ID == null)
            {
                ID = Storage_File.GetUniqueId(Type.Note);
                markDirty = true;
            }

            string versionstring = subtree.GetAttribute("Version");
            if (!string.IsNullOrEmpty(versionstring))
                Version = long.Parse(versionstring);

            versionstring = subtree.GetAttribute("LastSyncedVersion");
            if (!string.IsNullOrEmpty(versionstring))
                LastSyncedVersion = long.Parse(versionstring);

            string activestring = subtree.GetAttribute("Active");
            if (!string.IsNullOrEmpty(activestring))
                Active = bool.Parse(activestring);

            string name = subtree.GetAttribute("Name");
            if (name == null)
                throw (new Exception("Error reading name of note"));
            else
                Name = name;

            string iconID = subtree.GetAttribute("IconID");
            if (!string.IsNullOrEmpty(iconID))
                IconID = int.Parse(iconID);

            Content = subtree.GetAttribute("Content");
            if (Content == null)
            {
                Content = string.Empty;
                markDirty = true;
            }

            NotificationText = subtree.GetAttribute("NotificationText");
            if (NotificationText == null)
            {
                NotificationText = string.Empty;
                markDirty = true;
            }

            string notificationTime = subtree.GetAttribute("NotificationTime");
            if (notificationTime != null)
                NotificationTime = DateTime.Parse(notificationTime);

            subtree.Close();

            m_deserializing = false;

            if (markDirty)
                IsDirty = true;
        }
        #endregion

        #region Operators
        public override bool IsEqual(Node_Common other)
        {
            if (other.NodeType == Type.Note)
            {
                Node_Note note = other as Node_Note;
                if ((note != null) &&
                    this.ID.Equals(note.ID) &&
                    this.Name.Equals(note.Name) &&
                    this.Content.Equals(note.Content))
                {
                    return true;
                }
            }

            return false;
        }

        public override bool Contains(string searchstring)
        {
            return (this.Name.ToLower().Contains(searchstring) || 
                    this.Content.ToLower().Contains(searchstring));
        }

        public override bool Merge(Node_Common other)
        {
            Node_Note note = other as Node_Note;
            if(note == null)
                return false;

            Debug.Assert(LastSyncedVersion <= Version);
            Debug.Assert(LastSyncedVersion <= note.Version);

            if (LastSyncedVersion == note.Version)
            {
                //we have the latest stuff. simple return.
                return true;
            }
            else if (LastSyncedVersion < note.Version)
            {
                //cannot handle cases where this note is dirty
                if (IsDirty)
                    return false;

                if (LastSyncedVersion == Version)
                {
                    //pick up the other stuff
                    this.Name = note.Name;
                    this.IconID = note.IconID;
                    this.Content = note.Content;
                    this.NotificationText = note.NotificationText;
                    this.NotificationTime = note.NotificationTime;
                }
            }

            return false;
        }
        #endregion
    }
}
